<?php 
return [
    'labels' => [
        'GoodsType' => 'GoodsType',
        'goods-type' => 'GoodsType',
    ],
    'fields' => [
        'name' => '名称',
        'supply_count' => '供应数',
        'purchase_count' => '采购数',
    ],
    'options' => [
    ],
];
