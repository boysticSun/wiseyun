<?php
return [
    'labels' => [
        'User' => '用户',
        'users' => '用户',
    ],
    'fields' => [
        'name' => '用户名',
        'user_type_id' => '用户类型',
        'email' => '电子邮箱',
        'email_verified_at' => '邮箱认证时间',
        'mobile' => '手机号',
        'mobile_verified_at' => '手机认证时间',
        'password' => '密码',
        'qq' => 'QQ',
        'remember_token' => '记住我令牌',
        'avatar' => '头像',
        'introduction' => '个人简介',
    ],
    'options' => [
    ],
];
