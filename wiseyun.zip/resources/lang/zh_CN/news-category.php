<?php
return [
    'labels' => [
        'NewsCategory' => '新闻分类',
        'newscategories' => '新闻分类',
    ],
    'fields' => [
        'name' => '名称',
        'description' => '描述',
        'post_count' => '新闻资讯数',
        'pid' => '父级',
    ],
    'options' => [
    ],
];
