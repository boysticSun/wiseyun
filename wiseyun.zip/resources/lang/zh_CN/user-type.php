<?php
return [
    'labels' => [
        'UserType' => '用户类型',
        'usertypes' => '用户类型',
    ],
    'fields' => [
        'name' => '名称',
        'description' => '描述',
        'user_count' => '用户数',
    ],
    'options' => [
    ],
];
