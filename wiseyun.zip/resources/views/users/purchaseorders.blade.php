@extends('layouts.app')

@section('title', '售出订单')

@section('content')
  <div class="mt-5">

  </div>
@stop
