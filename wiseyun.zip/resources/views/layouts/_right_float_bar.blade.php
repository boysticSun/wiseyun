<div class="right-float-bar">
  <div class="item py-2 mb-2">
    <i class="fa-brands fa-qq"></i>
    <div class="title">QQ咨询</div>
  </div>
  <div class="item py-2 mb-2">
    <i class="fa-solid fa-phone"></i>
    <div class="title">电话咨询</div>
  </div>
  <div class="item py-2 mb-2">
    <i class="fa-solid fa-shield"></i>
    <div class="title">备案</div>
  </div>
  <div class="item py-2 mb-2">
    <i class="fa-solid fa-clipboard-list"></i>
    <div class="title">工单</div>
  </div>
  <div class="item" id="go-top">
    <div class="py-2">
      <i class="fa-solid fa-arrow-up"></i>
      <div class="title">TOP</div>
    </div>
  </div>
</div>
