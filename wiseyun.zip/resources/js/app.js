import './bootstrap';

import swiper,{ Autoplay, FreeMode, Pagination, Scrollbar, Mousewheel } from 'swiper';
swiper.use([Autoplay, FreeMode, Pagination, Scrollbar, Mousewheel]);
window.swiper = swiper;
