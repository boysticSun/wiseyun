<?php

namespace App\Observers;

use App\Models\SupplyOrder;

// creating, created, updating, updated, saving,
// saved,  deleting, deleted, restoring, restored

class SupplyOrderObserver
{
    public function creating(SupplyOrder $supply_order)
    {
        //
    }

    public function updating(SupplyOrder $supply_order)
    {
        //
    }
}