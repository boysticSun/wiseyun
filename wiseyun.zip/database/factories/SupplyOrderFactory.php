<?php

namespace Database\Factories;

use App\Models\SupplyOrder;
use Illuminate\Database\Eloquent\Factories\Factory;

class SupplyOrderFactory extends Factory
{
    protected $model = SupplyOrder::class;

    public function definition()
    {
        return [
            // $this->faker->name,
        ];
    }
}
