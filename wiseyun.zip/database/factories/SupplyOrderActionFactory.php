<?php

namespace Database\Factories;

use App\Models\SupplyOrderAction;
use Illuminate\Database\Eloquent\Factories\Factory;

class SupplyOrderActionFactory extends Factory
{
    protected $model = SupplyOrderAction::class;

    public function definition()
    {
        return [
            // $this->faker->name,
        ];
    }
}
