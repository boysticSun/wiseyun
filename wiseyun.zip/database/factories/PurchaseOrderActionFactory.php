<?php

namespace Database\Factories;

use App\Models\PurchaseOrderAction;
use Illuminate\Database\Eloquent\Factories\Factory;

class PurchaseOrderActionFactory extends Factory
{
    protected $model = PurchaseOrderAction::class;

    public function definition()
    {
        return [
            // $this->faker->name,
        ];
    }
}
